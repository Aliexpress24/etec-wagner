
    function buscar() {
      const termo = document.getElementById("busca").value.trim().toLowerCase();
      const container = document.getElementById("resultados");
      container.innerHTML = "";

      fetch("https://fakestoreapi.com/products")
        .then(res => res.json())
        .then(data => {
          const filtrados = data.filter(prod => prod.title.toLowerCase().includes(termo));

          if (filtrados.length === 0) {
            container.innerHTML = "<p>Nenhum produto encontrado.</p>";
            return;
          }

          filtrados.forEach(produto => {
            container.innerHTML += `
              <div class="produto">
                <img src="${produto.image}" alt="${produto.title}">
                <div>
                  <strong>${produto.title}</strong><br>
                  R$ ${produto.price.toFixed(2)}<br>
                  <p>${produto.description.substring(0, 100)}...</p>
                </div>
              </div>
            `;
          });
        })
        .catch(err => {
          console.error("Erro ao buscar produtos:", err);
          container.innerHTML = "<p>Erro ao buscar produtos. Tente novamente.</p>";
        });
    }