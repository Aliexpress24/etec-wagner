<!DOCTYPE html>
<html lang="en">
<head>
<link rel="icon" href="data:,">
    <link rel="stylesheet" href="estilo.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>PHP JSON COMPOSER</h1>
    <h2>Gerenciar Alunos</h2>
    <a href="./views/alunos.php">Gerenciar Alunos </a>
</body>
</html>