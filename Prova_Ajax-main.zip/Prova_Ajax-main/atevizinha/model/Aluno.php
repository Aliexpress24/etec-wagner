<?php

 class Aluno{

   public $nome;
   public $idade;     

    function __construct($nome, $idade) {
    
        $this->nome = $nome;
        $this->idade = $idade;

    }
 }