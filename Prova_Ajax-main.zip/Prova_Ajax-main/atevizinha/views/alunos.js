class Aluno {
    constructor(idade, nome) {
        this.idade = idade;
        this.nome = nome;
    }
}
